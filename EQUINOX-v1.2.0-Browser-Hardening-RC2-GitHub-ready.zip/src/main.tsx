import { createRoot } from "react-dom/client";
import { App } from "./ui/App";
import "./ui/styles.css";
import "./ui/browser-hardening.css";
createRoot(document.getElementById("root")!).render(<App />);
